Jaka SDK Version 2.2.1

Documentation can be found at: http://jaka.com/docs

Installation instructions:

Extract the zip contents into your main program directory, add them to your project using your IDE's 
way of importing headers. 

Import the 2 headers using:

using jkType;
using jakaApi;